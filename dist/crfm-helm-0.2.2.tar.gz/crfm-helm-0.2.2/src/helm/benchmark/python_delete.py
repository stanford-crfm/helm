import os
import glob
import pandas as pd


source_folder = "/home/rahul.mate/conversation_data/"
destination_folder = "/home/toshishjawale/conversation-summary-dataset/"


csv_files = glob.glob(os.path.join(source_folder, '*.csv'))
print(csv_files)


merged_data = pd.DataFrame()
for file in csv_files:
    df = pd.read_csv(file)
    if "General" in str(file) or "general" in str(file):
        df["meeting_type"] = ["General" for idx in range(len(df))]
    else:
        df["meeting_type"] = ["Sales" for idx in range(len(df))]
    if "action" not in file:
        merged_data = merged_data.append(df, ignore_index=True)
merged_data = merged_data.drop(merged_data.columns[merged_data.columns.str.contains('^Unnamed')], axis=1)

merged_data.to_csv(os.path.join(destination_folder, 'Symbl_summarization_all.csv'), index=False)

