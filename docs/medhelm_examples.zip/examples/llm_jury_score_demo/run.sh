SCRIPT_DIR="$(dirname "$(realpath "$0")")"
cd $SCRIPT_DIR/$DIR

######### 1. Set environment variables #########

# Name of the benchmark suite (used to group results)
export SUITE_NAME="DEMO"

# Path to your run configuration file (.conf)
export RUN_ENTRIES_CONF_PATH="./llm_jury_score_demo.conf"

# Maximum number of evaluation instances to run (useful for quick testing)
export MAX_EVAL_INSTANCES=2

# Path to the directory where the results will be stored. (helm-run will create it if it doesn't exist)
export OUTPUT_PATH="./benchmark_output"

######### 2. Run the benchmark #########

helm-run \
  --conf-paths $RUN_ENTRIES_CONF_PATH \
  --max-eval-instances $MAX_EVAL_INSTANCES \
  --suite $SUITE_NAME \
  --output-path $OUTPUT_PATH

if [ $? -ne 0 ]; then
    echo "An error occurred while running the benchmark (helm-run)."
    exit 1
fi

######### 3. Create the leaderboard #########

helm-summarize \
  --auto-generate-schema \
  --suite $SUITE_NAME \
  --output-path $OUTPUT_PATH

if [ $? -ne 0 ]; then
    echo "An error occurred while creating the leaderboard (helm-summarize)."
    exit 1
fi

######### 4. Launch the leaderboard #########

helm-server \
  --suite $SUITE_NAME \
  --output-path $OUTPUT_PATH

if [ $? -ne 0 ]; then
    echo "An error occurred while launching the leaderboard server (helm-server)."
    exit 1
fi